 <!-- container-scroller -->

  <!-- plugins:js -->
  <script src="<?php echo base_url() ; ?>asset/node_modules/jquery/dist/jquery.min.js"></script>
  <script src="<?php echo base_url() ; ?>asset/node_modules/popper.js/dist/umd/popper.min.js"></script>
  <script src="<?php echo base_url() ; ?>asset/node_modules/bootstrap/dist/js/bootstrap.min.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <script src="<?php echo base_url() ; ?>asset/node_modules/chart.js/dist/Chart.min.js"></script>
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="<?php echo base_url() ; ?>asset/js/off-canvas.js"></script>
  <script src="<?php echo base_url() ; ?>asset/js/misc.js"></script>
  <script type="text/javascript" src="<?php echo base_url() ; ?>asset/plugin/datatables.min.js"></script>
  
  <script type="text/javascript" src="<?php echo base_url() ; ?>asset/plugin/modal/iziModal.min.js"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="<?php echo base_url() ; ?>asset/js/dashboard.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB5NXz9eVnyJOA81wimI8WYE08kW_JMe8g&callback=initMap" async defer></script>
  <script src="<?php echo base_url() ; ?>asset/js/maps.js"></script>
  <!-- End custom js for this page-->
