  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Aplikasi Pelaporan Dana BOS</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="<?php echo base_url() ; ?>asset/node_modules/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="<?php echo base_url() ; ?>asset/node_modules/simple-line-icons/css/simple-line-icons.css">
  <link rel="stylesheet" href="<?php echo base_url() ; ?>asset/node_modules/font-awesome/css/font-awesome.min.css" />
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>asset/css/style.css">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url() ; ?>asset/plugin/datatables.min.css"/>
  <link rel="stylesheet" type="text/css" href="<?php echo base_url() ; ?>asset/plugin/modal/iziModal.min.css"/>
  <!-- endinject -->
  <link rel="shortcut icon" href="<?php echo base_url() ; ?>asset/images/favicon.png" />
